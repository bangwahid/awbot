let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]

    const timeout = 86400000 // 1 hari (24 jam)
    let time = (user.lastfreelimit || 0) + timeout

    if (new Date - (user.lastfreelimit || 0) < timeout) {
        return conn.reply(m.chat, `
╭───〔 ⏳ FREE LIMIT 〕───⬣
│ Kamu sudah klaim hari ini
│ ⏱️ Tunggu : ${clockString(time - new Date())}
╰──────────────────────⬣
`.trim(), m)
    }

    let jumlah = 10

    user.limit += jumlah
    user.lastfreelimit = new Date * 1

    conn.reply(m.chat, `
╭───〔 🎁 FREE LIMIT 〕───⬣
│ Kamu mendapatkan:
│ 🎫 Limit : +${jumlah}
│
│ Gunakan dengan bijak ya!
╰──────────────────────⬣
`.trim(), m)
}

handler.help = ['freelimit']
handler.tags = ['rpg']
handler.command = /^(freelimit|claimlimit)$/i
handler.register = true

module.exports = handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}