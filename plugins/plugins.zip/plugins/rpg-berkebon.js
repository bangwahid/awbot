const timeout = 1800000

let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let apelu = user.bibitapel
    let angguru = user.bibitanggur
    let manggau = user.bibitmangga
    let pisangu = user.bibitpisang
    let jeruku = user.bibitjeruk

    let time = user.lastberkebon + timeout

    if (apelu < 500 || angguru < 500 || manggau < 500 || pisangu < 500 || jeruku < 500) {
        return conn.reply(m.chat,
`🌱 *Bibit kamu belum cukup untuk berkebon!*

Minimal membutuhkan:
🍎 Bibit Apel : 500
🍇 Bibit Anggur : 500
🍌 Bibit Pisang : 500
🍊 Bibit Jeruk : 500
🥭 Bibit Mangga : 500

📦 Beli bibit di shop:
${usedPrefix}shop buy bibitmangga 500`, m)
    }

    if (new Date - user.lastberkebon < timeout) {
        return conn.reply(m.chat,
`⏳ *Kebun kamu masih dalam proses panen!*

🕒 Tunggu selama:
${msToTime(time - new Date())}

🌿 Sabar ya kak 😅`, m)
    }

    let pisangpoin = Math.floor(Math.random() * 500)
    let anggurpoin = Math.floor(Math.random() * 500)
    let manggapoin = Math.floor(Math.random() * 500)
    let jerukpoin = Math.floor(Math.random() * 500)
    let apelpoin = Math.floor(Math.random() * 500)

    user.pisang += pisangpoin
    user.anggur += anggurpoin
    user.mangga += manggapoin
    user.jeruk += jerukpoin
    user.apel += apelpoin
    user.tiketcoin += 1

    user.bibitpisang -= 500
    user.bibitanggur -= 500
    user.bibitmangga -= 500
    user.bibitjeruk -= 500
    user.bibitapel -= 500

    user.lastberkebon = new Date * 1

    conn.reply(m.chat,
`🌾 *HASIL BERKEBUN* 🌾

🍌 Pisang : +${pisangpoin}
🥭 Mangga : +${manggapoin}
🍇 Anggur : +${anggurpoin}
🍊 Jeruk : +${jerukpoin}
🍎 Apel : +${apelpoin}

🎟️ Tiketcoin : +1

✨ Bibit berhasil ditanam dan dipanen!`, m)

    setTimeout(() => {
        conn.reply(m.chat,
`🌱 Kebunmu sudah siap dipanen lagi!

Yuk berkebon lagi sekarang 😆`, m)
    }, timeout)
}

handler.help = ['berkebon']
handler.tags = ['rpg']
handler.command = /^(berkebon|kebun|berkebun)$/i

handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false
handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.rpg = true
handler.limit = true
handler.exp = 0
handler.money = 0

module.exports = handler

function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = (hours < 10) ? "0" + hours : hours
    minutes = (minutes < 10) ? "0" + minutes : minutes
    seconds = (seconds < 10) ? "0" + seconds : seconds

    return hours + " jam " + minutes + " menit " + seconds + " detik"
}