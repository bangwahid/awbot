let handler = async (m, { conn }) => {
    let users = global.db.data.users
    let user = users[m.sender]

    let dapat = Math.floor(Math.random() * 100000) + 1000
    let healtu = Math.floor(Math.random() * 100) + 1

    let who

    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat

    if (!who) {
        return conn.reply(m.chat,
`⚔️ Tag target yang ingin kamu serang!

Contoh:
.membunuh @user`, m)
    }

    if (typeof users[who] == 'undefined') {
        throw '❌ User tidak ditemukan di database.'
    }

    if (who === m.sender) {
        throw '❌ Kamu tidak bisa menyerang diri sendiri.'
    }

    let target = users[who]

    let __timers = (new Date - user.lastbunuhi)
    let _timers = (3600000 - __timers)
    let timers = clockString(_timers)

    if (new Date - user.lastbunuhi < 3600000) {
        return conn.reply(m.chat,
`⏳ Kamu baru saja melakukan pembunuhan!

🕒 Tunggu:
${timers}

🩸 Sebaiknya sembunyi dulu dari polisi...`, m)
    }

    if (target.healt < 10) {
        throw '💀 Target sudah sekarat dan tidak memiliki health cukup.'
    }

    if (target.money < 100) {
        throw '💸 Target tidak memiliki money yang bisa dirampas.'
    }

    if (dapat > target.money) dapat = target.money

    target.healt -= healtu
    target.money -= dapat

    user.money += dapat
    user.lastbunuhi = new Date * 1

    conn.reply(m.chat,
`🔪 *PEMBUNUHAN BERHASIL* 🔪

🎯 Target: @${who.split('@')[0]}

💰 Money dirampas:
+${dapat}

🩸 Health target berkurang:
-${healtu} Health

🏦 Total money kamu:
${user.money} Money

⚠️ Hati-hati, polisi sedang mencarimu...`,
m, {
mentions: [who]
})
}

handler.help = ['membunuh @user']
handler.tags = ['rpg']
handler.command = /^membunuh$/i
handler.limit = true
handler.group = true
handler.rpg = true

module.exports = handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, 0))
        .join(':')
}