let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let paus = user.paus || 0
    let kepiting = user.kepiting || 0
    let gurita = user.gurita || 0
    let cumi = user.cumi || 0
    let buntal = user.buntal || 0
    let dory = user.dory || 0
    let lumba = user.lumba || 0
    let lobster = user.lobster || 0
    let hiu = user.hiu || 0
    let udang = user.udang || 0
    let ikan = user.ikan || 0
    let orca = user.orca || 0

    let total = paus + kepiting + gurita + cumi + buntal + dory + lumba + lobster + hiu + udang + ikan + orca

    let text = `
╭━━━〔 🎣 FISH POND 〕━━━⬣
👤 Player : @${m.sender.split`@`[0]}

🐟 IKAN HASIL TANGKAPAN
🦈 Hiu       : ${hiu}
🐠 Ikan      : ${ikan}
🐬 Dory      : ${dory}
🐋 Orca      : ${orca}
🐳 Paus      : ${paus}

🦑 LAUT DALAM
🐙 Cumi      : ${cumi}
🪼 Gurita    : ${gurita}
🐡 Buntal    : ${buntal}
🦐 Udang     : ${udang}
🐬 Lumba²    : ${lumba}
🦞 Lobster   : ${lobster}
🦀 Kepiting  : ${kepiting}

📊 TOTAL IKAN : ${total}

💡 Gunakan *${usedPrefix}mancing* untuk menangkap lagi
╰━━━━━━━━━━━━━━━━⬣
`.trim()

    conn.reply(m.chat, text, m, {
        mentions: await conn.parseMention(text)
    })
}

handler.help = ['kolam']
handler.tags = ['rpg']
handler.command = /^(kolam)$/i
handler.group = true
handler.rpg = true

module.exports = handler