const axios = require("axios")
const cheerio = require("cheerio")

let handler = async (m, { conn, text, usedPrefix, command }) => {

    if (!text)
        return conn.reply(
            m.chat,
`❌ Masukkan judul film

Contoh:
${usedPrefix + command} avengers`,
            m
        )

    try {

        await conn.reply(
            m.chat,
            `🔎 Sedang mencari film *${text}*...`,
            m
        )

        let { result } = await film(text)

        // =========================
        // NO RESULT
        // =========================
        if (!result || result.length < 1) {

            return conn.reply(
                m.chat,
`
╭──〔 ❌ FILM TIDAK DITEMUKAN 〕
│ Film belum tersedia di web
│
│ 📩 Silahkan request ke admin
╰────────────────────⬣
`.trim(),
                m
            )
        }

        // =========================
        // HEADER
        // =========================
        let caption =
`
╭──〔 🎬 RUANGMOVIEZ SEARCH 〕
│ 🔎 Query : ${text}
╰────────────────────⬣
`.trim()

        // =========================
        // RESULT
        // =========================
        for (let i = 0; i < result.length; i++) {

            let v = result[i]

            caption += `

╭─❍ ${i + 1}. ${v.title}
│ 🎭 Genre : ${v.genre}
│ ⏳ Duration : ${v.duration}
│ 🌍 Country : ${v.country}
│ 👥 Actor : ${v.actor}
│ 🎥 Quality : ${v.quality}
│ 🔗 Link :
│ ${v.link}
╰────────────────────⬣
`
        }

        // =========================
        // SEND
        // =========================
        await conn.reply(
            m.chat,
            caption.trim(),
            m
        )

    } catch (e) {

        console.log(e)

        conn.reply(
            m.chat,
`
❌ Error Film Search

📌 ${e.message || e}

⚡ Powered by AW BOT
`.trim(),
            m
        )
    }
}

handler.help = ['film']
handler.tags = ['internet']
handler.command = /^(film)$/i

module.exports = handler

// =========================
// SCRAPER
// =========================
async function film(query) {

    try {

        let { data } = await axios.get(
            'https://ruangmoviez.my.id/?s=' +
            encodeURIComponent(query)
        )

        let $ = cheerio.load(data)

        let movies = []

        let items =
            $('article.item-infinite')
            .slice(0, 10)

        for (let el of items) {

            // =========================
            // BASIC DATA
            // =========================
            let title =
                $(el)
                .find('h2.entry-title a')
                .text()
                .trim()

            let link =
                $(el)
                .find('a[itemprop="url"]')
                .attr('href')

            let genre =
                $(el)
                .find('a[rel="category tag"]')
                .map((i, e) => $(e).text())
                .get()
                .join(', ') || '-'

            // =========================
            // DEFAULT DETAIL
            // =========================
            let quality = '-'
            let duration = '-'
            let country = '-'
            let actor = '-'

            // =========================
            // DETAIL SCRAPE
            // =========================
            try {

                let detail =
                    await axios.get(link)

                let $$ =
                    cheerio.load(detail.data)

                // QUALITY
                quality =
                    $$('div.gmr-moviedata')
                    .filter((i, el) =>
                        $$(el)
                        .find('strong')
                        .text()
                        .includes('Quality')
                    )
                    .find('a')
                    .first()
                    .text()
                    .trim() || '-'

                // DURATION
                duration =
                    $$('span[property="duration"]')
                    .first()
                    .text()
                    .trim() || '-'

                // COUNTRY
                country =
                    $$('span[itemprop="contentLocation"] a')
                    .first()
                    .text()
                    .trim() || '-'

                // ACTOR
                actor =
                    $$('span[itemprop="actors"] a')
                    .slice(0, 3)
                    .map((i, e) =>
                        $$(e).text().trim()
                    )
                    .get()
                    .join(', ') || '-'

            } catch (e) {
                console.log(
                    'Detail scrape error:',
                    e.message
                )
            }

            movies.push({
                title,
                link,
                genre,
                quality,
                duration,
                country,
                actor
            })
        }

        return {
            status: 200,
            result: movies
        }

    } catch (e) {

        return {
            status: 404,
            msg: e.message,
            result: []
        }
    }
}