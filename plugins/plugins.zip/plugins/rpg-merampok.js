let handler = async (m, { conn }) => {
  let dapat = Math.floor(Math.random() * 100000)

  let who = m.isGroup ? m.mentionedJid[0] : m.chat
  if (!who) return conn.reply(m.chat, '❌ Tag salah satu target!', m)

  if (typeof global.db.data.users[who] == 'undefined')
    return conn.reply(m.chat, '❌ Target tidak ada di database', m)

  let user = global.db.data.users
  let sender = global.db.data.users[m.sender]

  let cooldown = 3600000
  let time = sender.lastrob || 0
  let remaining = cooldown - (Date.now() - time)

  if (Date.now() - time < cooldown) {
    return conn.reply(m.chat,
`╭──〔 ⏳ COOLDOWN ROB 〕──⬣
│ 🚔 Kamu baru saja merampok
│ ⏱️ Tunggu : ${clockString(remaining)}
╰──────────────────⬣`, m)
  }

  if (user[who].money < 10000) {
    return conn.reply(m.chat,
`╭──〔 ❌ GAGAL ROB 〕──⬣
│ 💸 Target terlalu miskin
│ 🪙 Uang : ${user[who].money}
╰──────────────────⬣`, m)
  }

  let take = Math.min(dapat, user[who].money)

  user[who].money -= take
  user[m.sender].money += take
  sender.lastrob = Date.now()

  conn.reply(m.chat,
`╭──〔 🏴‍☠️ ROBBERY SUCCESS 〕──⬣
│ 🎯 Target berhasil dirampok
│ 💰 Uang diambil : ${take}
│ 🧑‍✈️ Dari user : @${who.split('@')[0]}
╰──────────────────⬣`, m, {
    mentions: [who]
  })
}

handler.help = ['merampok @user']
handler.tags = ['rpg']
handler.command = /^merampok|rampok$/i
handler.limit = true
handler.group = true
handler.rpg = true

module.exports = handler

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60

  return [h, m, s]
    .map(v => v.toString().padStart(2, '0'))
    .join(':')
}