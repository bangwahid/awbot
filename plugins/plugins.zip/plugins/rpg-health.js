let handler = async (m, { args, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    const maxHealth = 100
    const heal = 10

    if (user.healt >= maxHealth) {
        return m.reply(`╭──〔 ❤️ HEALTH FULL 〕──⬣
│ Health kamu sudah penuh
│ ❤️ ${user.healt}/${maxHealth}
╰──────────────────⬣`)
    }

    // 🔥 BATASI MAX 5 POTION
    let count = args[0] ? parseInt(args[0]) : 1
    if (isNaN(count) || count < 1) count = 1
    if (count > 5) count = 5

    if (user.potion < count) {
        return m.reply(`╭──〔 🧃 POTION HABIS 〕──⬣
│ Potion kamu tidak cukup
│ 🧃 Dimiliki : ${user.potion}
│ ❗ Dibutuhkan : ${count}
╰──────────────────⬣`)
    }

    user.potion -= count
    user.healt += heal * count

    if (user.healt > maxHealth) user.healt = maxHealth

    m.reply(`╭──〔 ❤️ HEAL SUCCESS 〕──⬣
│ 🧃 Potion dipakai : ${count}
│ 🧃 Sisa : ${user.potion}
│ ❤️ Heal total     : +${heal * count}
│ ❤️ Health sekarang : ${user.healt}/${maxHealth}
╰──────────────────⬣`)
}

handler.help = ['heal <1-5>', 'use <1-5>']
handler.tags = ['rpg']
handler.command = /^(heal|use)$/i
handler.limit = true
handler.rpg = true

module.exports = handler