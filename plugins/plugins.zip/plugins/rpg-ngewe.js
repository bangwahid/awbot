let handler = async (m, { conn }) => {
    let __timers = (new Date - global.db.data.users[m.sender].lastngewe)
    let _timers = (300000 - __timers)
    let order = global.db.data.users[m.sender].ngewe
    let timers = clockString(_timers)

    let name = await conn.getName(m.sender)
    let user = global.db.data.users[m.sender]

    if (new Date - global.db.data.users[m.sender].lastngewe > 300000) {

        let randomaku1 = Math.floor(Math.random() * 10)
        let randomaku2 = Math.floor(Math.random() * 10)
        let randomaku3 = Math.floor(Math.random() * 10)
        let randomaku4 = Math.floor(Math.random() * 5)
        let randomaku5 = Math.floor(Math.random() * 10)

        let rbrb1 = (randomaku1 * 2)
        let rbrb2 = (randomaku2 * 10)
        let rbrb3 = (randomaku3 * 1)
        let rbrb4 = (randomaku4 * 15729)
        let rbrb5 = (randomaku5 * 20000)

        let proses = [
`╭━━〔 💋 NIGHT SERVICE 〕
┃ 🔎 Sedang mencari partner...
╰━━━━━━━━━━━━━━━━⬣`,

`╭━━〔 💋 NIGHT SERVICE 〕
┃ 👩 Partner ditemukan
┃ 💵 Negosiasi harga...
╰━━━━━━━━━━━━━━━━⬣`,

`╭━━〔 💋 NIGHT SERVICE 〕
┃ 🛏️ Memulai aktivitas...
┃ 💦 Mood meningkat...
╰━━━━━━━━━━━━━━━━⬣`,

`╭━━〔 💋 NIGHT SERVICE 〕
┃ 🥵 Aktivitas selesai
┃ 💸 Menghitung hasil...
╰━━━━━━━━━━━━━━━━⬣`
        ]

        let hasil =
`╭━━〔 💋 HASIL NIGHT SERVICE 〕
┃ 👤 Player : ${name}
┃
┃ 💹 Money : +${rbrb4}
┃ ✨ Exp : +${rbrb5}
┃ ⚠️ Warn : +1
┃ 📦 Total Order : ${order + 1}
┃
┃ 🎉 Transaksi berhasil
╰━━━━━━━━━━━━━━━━⬣

${wm}`

        let { key } = await conn.sendMessage(m.chat, {
            text: proses[0]
        })

        for (let i = 1; i < proses.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 4000))

            await conn.sendMessage(m.chat, {
                text: proses[i],
                edit: key
            })
        }

        await new Promise(resolve => setTimeout(resolve, 4000))

        await conn.sendMessage(m.chat, {
            text: hasil,
            edit: key
        })

        global.db.data.users[m.sender].warn += 1
        global.db.data.users[m.sender].money += rbrb4
        global.db.data.users[m.sender].exp += rbrb5
        global.db.data.users[m.sender].ngewe += 1

        user.lastngewe = new Date * 1

    } else {

        m.reply(
`╭━━〔 ⏳ COOLDOWN 〕━━⬣
┃ ❌ Kamu sudah memakai fitur ini
┃ 🕒 Tunggu : ${timers}
╰━━━━━━━━━━━━━━━━⬣`
        )
    }
}

handler.help = ['ngewe']
handler.tags = ['rpg']
handler.command = /^(ngewe|anu)$/i
handler.register = true
handler.premium = false
handler.rpg = true

module.exports = handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, 0))
        .join(':')
}