let handler = async (m, { conn, command, args, usedPrefix }) => {
  try {
    let bruh = `╭──〔 📦 OPEN CRATE 〕──⬣
│ Cara pakai:
│ *${usedPrefix}open <crate> <jumlah>*
│
│ Contoh:
│ *${usedPrefix}open common 1*
│ *${usedPrefix}open uncommon 10*
│
│ List crate:
│ • common
│ • uncommon
│ • mythic
│ • legendary
╰──────────────────⬣`

    let type = (args[0] || '').toLowerCase()
    let jumlah = Number(args[1])

    if (!type || !jumlah) return conn.reply(m.chat, bruh, m)

    // valid minimal 1
    let valid = [1, 10, 100, 1000]
    if (!valid.includes(jumlah)) {
      return conn.reply(m.chat, `╭──〔 ❌ INVALID JUMLAH 〕──⬣
│ Hanya support:
│ 1 / 10 / 100 / 1000
╰──────────────────⬣`, m)
    }

    let user = global.db.data.users[m.sender]

    const cek = (item, qty) => {
      if (user[item] < qty) {
        conn.reply(m.chat, `╭──〔 📦 GAGAL OPEN 〕──⬣
│ Crate ${type} kamu kurang
│ Dibutuhkan: ${qty}
╰──────────────────⬣`, m)
        return false
      }
      user[item] -= qty
      return true
    }

    switch (type) {

      // ================= COMMON =================
      case 'common': {
        if (!cek('common', jumlah)) return

        let money = Math.floor(Math.random() * 500 * jumlah)
        let exp = Math.floor(Math.random() * 700 * jumlah)
        let potion = Math.floor(Math.random() * 3 * jumlah)
        let common = Math.floor(Math.random() * 3 * jumlah)
        let uncommon = Math.floor(Math.random() * 2 * jumlah)

        user.money += money
        user.exp += exp
        user.potion += potion
        user.common += common
        user.uncommon += uncommon

        return conn.reply(m.chat, `╭──〔 📦 COMMON OPEN 〕──⬣
│ Jumlah : ${jumlah}
│ 💰 Money : +${money}
│ ✨ Exp   : +${exp}
│ 🧪 Potion: +${potion}
│ 📦 Common: +${common}
│ 🎁 Uncommon: +${uncommon}
╰──────────────────⬣`, m)
      }

      // ================= UNCOMMON =================
      case 'uncommon': {
        if (!cek('uncommon', jumlah)) return

        let money = Math.floor(Math.random() * 1000 * jumlah)
        let exp = Math.floor(Math.random() * 1500 * jumlah)
        let diamond = Math.floor(Math.random() * 5 * jumlah)
        let potion = Math.floor(Math.random() * 5 * jumlah)
        let common = Math.floor(Math.random() * 3 * jumlah)

        user.money += money
        user.exp += exp
        user.diamond += diamond
        user.potion += potion
        user.common += common

        return conn.reply(m.chat, `╭──〔 📦 UNCOMMON OPEN 〕──⬣
│ Jumlah  : ${jumlah}
│ 💰 Money : +${money}
│ ✨ Exp   : +${exp}
│ 💎 Diamond: +${diamond}
│ 🧪 Potion: +${potion}
│ 📦 Common: +${common}
╰──────────────────⬣`, m)
      }

      // ================= MYTHIC =================
      case 'mythic': {
        if (!cek('mythic', jumlah)) return

        let money = Math.floor(Math.random() * 3000 * jumlah)
        let exp = Math.floor(Math.random() * 5000 * jumlah)
        let diamond = Math.floor(Math.random() * 10 * jumlah)
        let potion = Math.floor(Math.random() * 10 * jumlah)
        let uncommon = Math.floor(Math.random() * 5 * jumlah)

        user.money += money
        user.exp += exp
        user.diamond += diamond
        user.potion += potion
        user.uncommon += uncommon

        return conn.reply(m.chat, `╭──〔 🔮 MYTHIC OPEN 〕──⬣
│ Jumlah  : ${jumlah}
│ 💰 Money : +${money}
│ ✨ Exp   : +${exp}
│ 💎 Diamond: +${diamond}
│ 🧪 Potion: +${potion}
│ 🎁 Uncommon: +${uncommon}
╰──────────────────⬣`, m)
      }

      // ================= LEGENDARY =================
      case 'legendary': {
        if (!cek('legendary', jumlah)) return

        let money = Math.floor(Math.random() * 10000 * jumlah)
        let exp = Math.floor(Math.random() * 20000 * jumlah)
        let diamond = Math.floor(Math.random() * 25 * jumlah)
        let potion = Math.floor(Math.random() * 20 * jumlah)
        let uncommon = Math.floor(Math.random() * 10 * jumlah)

        user.money += money
        user.exp += exp
        user.diamond += diamond
        user.potion += potion
        user.uncommon += uncommon

        return conn.reply(m.chat, `╭──〔 👑 LEGENDARY OPEN 〕──⬣
│ Jumlah  : ${jumlah}
│ 💰 Money : +${money}
│ ✨ Exp   : +${exp}
│ 💎 Diamond: +${diamond}
│ 🧪 Potion: +${potion}
│ 🎁 Uncommon: +${uncommon}
╰──────────────────⬣`, m)
      }

      default:
        return conn.reply(m.chat, bruh, m)
    }

  } catch (e) {
    console.log(e)
    conn.reply(m.chat, 'Error system open crate', m)
  }
}

handler.help = ['open <crate> <jumlah>']
handler.tags = ['rpg']
handler.command = /^(open|buka)$/i
handler.register = true
handler.rpg = true

module.exports = handler