const axios = require('axios');

/**
 * ======>> AW BOT QURAN SURAH FULL FIX <<======
 * FIX: duplicate verse issue + clean output
 */

async function getSurahData(slug) {
  try {
    const rscPayload = encodeURIComponent(JSON.stringify([
      "",
      {
        children: [
          ["slug", slug, "d"],
          {
            children: [`__PAGE__?{"slug":"${slug}"}`, {}]
          }
        ]
      },
      null,
      null,
      true
    ]));

    const { data } = await axios.get(`https://quran.nu.or.id/${slug}`, {
      params: { _rsc: 'k8ba4' },
      headers: {
        'RSC': '1',
        'Next-Router-State-Tree': rscPayload,
        'Next-Url': `/${slug}`,
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
      },
      responseType: 'text'
    });

    const result = {
      creator: "AW BOT",
      info: {},
      verses: []
    };

    // ===== SURAH INFO =====
    const surahMatch = data.match(
      /"name":"([^"]+)","slug":"([^"]+)","translate":"([^"]+)","type":"([^"]+)","verse_count":(\d+),"juz_id":(\d+)/
    );

    if (surahMatch) {
      result.info = {
        namaSurah: surahMatch[1],
        slug: surahMatch[2],
        terjemahan: surahMatch[3],
        tipe: surahMatch[4],
        jumlahAyat: parseInt(surahMatch[5]),
        juz: parseInt(surahMatch[6])
      };
    }

    // ===== VERSE EXTRACTION =====
    const verseMatches = [...data.matchAll(
      /"transliteration":"([^"]+)","text":"([^"]+)","translation_id":"([^"]+)"/g
    )];

    // ===== FIX DUPLICATE =====
    const seen = new Set();

    for (const match of verseMatches) {
      const arab = match[2];

      if (seen.has(arab)) continue; // anti duplicate
      seen.add(arab);

      result.verses.push({
        latin: match[1],
        arab: match[2],
        terjemahan: match[3]
      });
    }

    return { status: true, data: result };

  } catch (e) {
    return { status: false, creator: "AW BOT", error: e.message };
  }
}

// ===== HANDLER =====
let handler = async (m, { text }) => {
  if (!text) {
    return m.reply(
`📖 AW BOT QURAN SURAH

Cara pakai:
.quran al-falaq
.quran al-ikhlas
.quran al-baqarah`
    );
  }

  const slug = text.trim().toLowerCase();

  m.reply('⏳ AW BOT sedang mengambil semua ayat...');

  const output = await getSurahData(slug);

  if (!output.status) {
    return m.reply('❌ Gagal mengambil data surah.');
  }

  const info = output.data.info;
  const verses = output.data.verses;

  // ===== BACAAN SURAH =====
  let bacaanSurah = verses.map((v, i) => {
    return (
`\n📍 Ayat ${i + 1}
${v.arab}
_${v.latin}_
${v.terjemahan}`
    );
  }).join('\n');

  let caption =
`╭━━━〔 📖 AW BOT QURAN 〕━━━⬣\n` +
`┃\n` +
`┃ 📌 Surah : ${info.namaSurah || '-'}\n` +
`┃ 🕌 Arti  : ${info.terjemahan || '-'}\n` +
`┃ 📊 Ayat  : ${info.jumlahAyat || '-'}\n` +
`┃ 📘 Juz   : ${info.juz || '-'}\n` +
`┃\n` +
`┣━━━〔 📜 BACAAN SURAH 〕━━━⬣\n` +
`┃${bacaanSurah}\n` +
`┃\n` +
`╰━━━━━━━━━━━━━━━━━━⬣`;

  return m.reply(caption);
};

handler.help = ['quran'];
handler.tags = ['islami'];
handler.command = /^(quran|surah)$/i;

module.exports = handler;
module.exports.getSurahData = getSurahData;