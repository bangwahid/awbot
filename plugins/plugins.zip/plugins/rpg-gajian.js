let handler = async (m, { conn, usedPrefix, text }) => { 
    let user = global.db.data.users[m.sender]

    if (!user) throw 'User tidak ditemukan di database.'

    let cooldown = 43200000 // 24 jam
    let now = Date.now()

    let lastClaim = user.lastclaimb2 || 0
    let timeLeft = cooldown - (now - lastClaim)

    if (now - lastClaim < cooldown) {
        throw `Kamu sudah ambil gaji hari ini.\nTunggu selama *${msToTime(timeLeft)}* lagi`
    }

    // 💼 GAJI POKOK (1.000.000 - 2.000.000)
    let gajiPokok = Math.floor(
        Math.random() * (2000000 - 1000000 + 1) + 1000000
    )

    // 🎁 TUNJANGAN (20% - 50% dari gaji pokok)
    let tunjangan = Math.floor(gajiPokok * (Math.random() * 0.3 + 0.2))

    // 💰 TOTAL GAJI
    let totalGaji = gajiPokok + tunjangan

    // tambah ke user
    user.money += totalGaji
    user.lastclaimb2 = now

    m.reply(
`💼 *SLIP GAJI HARIAN*
━━━━━━━━━━━━━━
💰 Gaji Pokok : Rp ${gajiPokok.toLocaleString()}
🎁 Tunjangan  : Rp ${tunjangan.toLocaleString()}
━━━━━━━━━━━━━━
💵 Total Gaji : Rp ${totalGaji.toLocaleString()}

✔ Kamu berhasil menerima gaji hari ini!`
    )
}

handler.help = ['gajian']
handler.tags = ['rpg']
handler.command = /^(gaji|gajian)/i

handler.register = true
handler.rpg = true

module.exports = handler


function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60)
    let minutes = Math.floor((duration / (1000 * 60)) % 60)
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = hours < 10 ? "0" + hours : hours
    minutes = minutes < 10 ? "0" + minutes : minutes
    seconds = seconds < 10 ? "0" + seconds : seconds

    return `${hours} jam ${minutes} menit ${seconds} detik`
}