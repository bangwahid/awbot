let handler = async (m, { conn, command, args, usedPrefix, DevMode }) => {
    let type = (args[0] || '').toLowerCase()
    let count = Math.max(1, Math.min(5, parseInt(args[1]) || 1))

    let user = global.db.data.users[m.sender]

    // 🎯 MENU UPGRADE
    let menu = `
╭━━━〔 🍳 COOKING SYSTEM 〕━━━⬣

🍗 AYAM
▸ ayambakar     = 2 ayam + 1 coal
▸ ayamgoreng    = 2 ayam + 1 coal
▸ oporayam      = 2 ayam + 1 coal
▸ gulaiayam     = 2 ayam + 1 coal

🥩 SAPI
▸ steak         = 2 sapi + 1 coal
▸ rendang       = 2 sapi + 1 coal

🐖 BABI
▸ babipanggang  = 2 babi + 1 coal

🐟 IKAN
▸ ikanbakar     = 2 ikan + 1 coal
▸ lelebakar     = 2 lele + 1 coal
▸ nilabakar     = 2 nila + 1 coal
▸ bawalbakar    = 2 bawal + 1 coal

🦐 LAUT
▸ udangbakar    = 2 udang + 1 coal
▸ pausbakar     = 2 paus + 1 coal
▸ kepitingbakar = 2 kepiting + 1 coal

💡 Cara pakai:
${usedPrefix}masak ayambakar 1-5
╰━━━━━━━━━━━━━━━━⬣
`

    try {

        let success = (item, text) => `
╭━━━〔 🍳 BERHASIL MASAK 〕━━━⬣
│ 🍽️ Menu   : ${item}
│ 🔢 Jumlah : ${count}
│ 🔥 Status : SUCCESS
╰━━━━━━━━━━━━━━━━⬣

✨ ${text}
`

        let fail = `
╭━━━〔 ❌ GAGAL MASAK 〕━━━⬣
│ Bahan tidak cukup!
│ 🔎 Cek inventory kamu dulu
╰━━━━━━━━━━━━━━━━⬣
`

        switch (type) {

            case 'ayambakar':
            case 'ayamgoreng':
            case 'oporayam':
            case 'gulaiayam':
                if (user.ayam < count * 2 || user.coal < count) return m.reply(fail)
                user.ayam -= count * 2
                user.coal -= count
                user[type] = (user[type] || 0) + count
                return m.reply(success(type, `Makanan ayam berhasil dibuat 🍗`))

            case 'steak':
            case 'rendang':
                if (user.sapi < count * 2 || user.coal < count) return m.reply(fail)
                user.sapi -= count * 2
                user.coal -= count
                user[type] = (user[type] || 0) + count
                return m.reply(success(type, `Masakan sapi siap disajikan 🥩`))

            case 'babipanggang':
                if (user.babi < count * 2 || user.coal < count) return m.reply(fail)
                user.babi -= count * 2
                user.coal -= count
                user.babipanggang = (user.babipanggang || 0) + count
                return m.reply(success(type, `Babi panggang matang sempurna 🔥`))

            case 'ikanbakar':
            case 'lelebakar':
            case 'nilabakar':
            case 'bawalbakar':
                if (user[type.replace('bakar','')] < count * 2 || user.coal < count) return m.reply(fail)
                user[type.replace('bakar','')] -= count * 2
                user.coal -= count
                user[type] = (user[type] || 0) + count
                return m.reply(success(type, `Hasil laut sudah matang 🐟`))

            case 'udangbakar':
            case 'pausbakar':
            case 'kepitingbakar':
                let raw = type.replace('bakar','')
                if (user[raw] < count * 2 || user.coal < count) return m.reply(fail)
                user[raw] -= count * 2
                user.coal -= count
                user[type] = (user[type] || 0) + count
                return m.reply(success(type, `Hasil laut bakar siap dimakan 🦐`))

            default:
                return conn.reply(m.chat, menu, m)
        }

    } catch (e) {
        console.log(e)
        conn.reply(m.chat, '❌ Sistem memasak sedang error', m)

        if (DevMode) {
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')) {
                conn.sendMessage(jid, {
                    text: `ERROR COOK\nUser: ${m.sender}\nCmd: ${m.text}\n\n${e}`
                })
            }
        }
    }
}

handler.help = ['masak <menu> <jumlah>', 'cook <menu> <jumlah>']
handler.tags = ['rpg']
handler.command = /^(masak|cook)$/i
handler.group = true
handler.rpg = true

module.exports = handler