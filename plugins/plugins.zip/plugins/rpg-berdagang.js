let handler = async (m, { conn }) => {
    let dapat = Math.floor(Math.random() * 5000) + 1000
    let who

    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat

    if (!who) throw '🌸 Tag partner dagang kamu.\n\nContoh:\n.berdagang @user'
    if (typeof db.data.users[who] == 'undefined') throw 'User tidak ditemukan di database.'

    let users = global.db.data.users
    let user = users[m.sender]
    let partner = users[who]

    let __timers = (new Date - user.lastdagang)
    let _timers = (28800000 - __timers)
    let timers = clockString(_timers)

    if (new Date - user.lastdagang < 28800000) {
        return conn.reply(m.chat,
`⏳ Kamu sudah berdagang sebelumnya!

Silakan tunggu:
🕒 ${timers}`, m)
    }

    if (partner.money < 5000) {
        throw '💸 Target tidak memiliki modal minimal 5000 money.'
    }

    if (user.money < 5000) {
        throw '💸 Kamu membutuhkan minimal 5000 money untuk berdagang.'
    }

    user.money -= dapat
    partner.money -= dapat

    user.lastdagang = new Date * 1

    conn.reply(m.chat,
`🛒 *MEMULAI PERDAGANGAN*

👤 Partner: @${who.split('@')[0]}
💰 Modal kamu: -${dapat}
💰 Modal partner: -${dapat}

⏳ Perdagangan sedang berlangsung...`,
m, {
mentions: [who]
})

    const rewards = [
        { delay: 3600000, reward: 5000 },
        { delay: 7200000, reward: 5000 },
        { delay: 10800000, reward: 5000 },
        { delay: 14400000, reward: 5000 },
        { delay: 18000000, reward: 5000 },
        { delay: 21600000, reward: 5000 },
        { delay: 25200000, reward: 5000 },
        { delay: 28800000, reward: 10000 }
    ]

    for (let item of rewards) {
        setTimeout(() => {
            user.money += item.reward
            partner.money += item.reward

            conn.reply(m.chat,
`💹 *HASIL PERDAGANGAN*

👤 Partner: @${who.split('@')[0]}

💰 Kamu mendapatkan:
+${item.reward} Money

💰 Partner mendapatkan:
+${item.reward} Money

🏦 Saldo kamu sekarang:
${user.money} Money`,
m, {
mentions: [who]
})
        }, item.delay)
    }
}

handler.help = ['berdagang @tag']
handler.tags = ['rpg']
handler.command = /^berdagang$/i
handler.register = true
handler.group = true
handler.rpg = true

module.exports = handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, 0))
        .join(':')
}