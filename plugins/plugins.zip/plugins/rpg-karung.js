let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let cap = `*━ ❨ KARUNG HASIL MULUNG ❩ ━*

👤 => Karung milik : @${m.sender.split`@`[0]}

📦 *HASIL MULUNG*
🥫 Kaleng   = [ ${user.kaleng || 0} ]
🧴 Botol    = [ ${user.botol || 0} ]
📦 Kardus   = [ ${user.kardus || 0} ]
🗑️ Sampah   = [ ${user.sampah || 0} ]

🎁 *BOX ITEM*
📦 Common    = [ ${user.common || 0} ]
📦 Uncommon  = [ ${user.uncommon || 0} ]
🔮 Mythic    = [ ${user.mythic || 0} ]
👑 Legendary = [ ${user.legendary || 0} ]

💡 Gunakan *${usedPrefix}sell* untuk menjual hasil`

    conn.reply(m.chat, cap, m, {
        mentions: await conn.parseMention(cap)
    })
}

handler.help = ['karung']
handler.tags = ['rpg']
handler.command = /^(karung)$/i
handler.rpg = true

module.exports = handler