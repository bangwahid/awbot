const timeout = 1800000 // 30 menit

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]

  user.money = user.money || 0
  user.atm = user.atm || 0
  user.exp = user.exp || 0
  user.kardus = user.kardus || 0
  user.diamond = user.diamond || 0
  user.emas = user.emas || 0
  user.berlian = user.berlian || 0

  let time = user.lastmaling + timeout

  if (new Date - user.lastmaling < timeout) {
    return conn.reply(m.chat, `
╭━━━〔 ⏳ COOLDOWN BANK ROBBERY 〕━━━⬣
┃ 🏦 Kamu baru saja merampok bank!
┃ ⏱️ Tunggu : ${msToTime(time - new Date())}
┃
╰━━━━━━━━━━━━━━━━⬣
`.trim(), m)
  }

  let sukses = Math.random() < 0.8 // 80% sukses

  let money = Math.floor(Math.random() * 30000)
  let exp = Math.floor(Math.random() * 999)
  let kardus = Math.floor(Math.random() * 1000)

  let diamond = Math.floor(Math.random() * 10)
  let emas = Math.floor(Math.random() * 20)
  let berlian = Math.floor(Math.random() * 5)

  let denda = Math.floor(Math.random() * 20000)

  user.lastmaling = new Date * 1

  // ❌ GAGAL
  if (!sukses) {
    let totalDenda = denda

    if (user.atm >= totalDenda) {
      user.atm -= totalDenda
    } else {
      let sisa = totalDenda - user.atm
      user.atm = 0
      user.money = Math.max(0, user.money - sisa)
    }

    return conn.reply(m.chat, `
╭━━━〔 ❌ MALING GAGAL 〕━━━⬣
┃ 🚔 Kamu ketahuan polisi!
┃ 💸 Denda : -${totalDenda}
┃ 💰 Money / ATM anda berkurang
╰━━━━━━━━━━━━━━━━⬣
`.trim(), m)
  }

  // ✅ SUKSES
  user.money += money
  user.exp += exp
  user.kardus += kardus
  user.diamond += diamond
  user.emas += emas
  user.berlian += berlian

  return conn.reply(m.chat, `
╭━━━〔 💰 MALING BERHASIL 〕━━━⬣
┃ 💵 Money   : +${money}
┃ ✨ Exp     : +${exp}
┃ 📦 Kardus  : +${kardus}
┃ 💎 Diamond : +${diamond}
┃ 🪙 Emas    : +${emas}
┃ 💠 Berlian : +${berlian}
╰━━━━━━━━━━━━━━━━⬣
`.trim(), m)
}

handler.help = ['maling']
handler.tags = ['rpg']
handler.command = /^(maling)$/i
handler.rpg = true
handler.limit = false

module.exports = handler

function msToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60)
  let minutes = Math.floor((duration / (1000 * 60)) % 60)
  let hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

  return `${hours} jam ${minutes} menit ${seconds} detik`
}