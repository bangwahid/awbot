let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]

    let last = user.lastberburu || 0
    let cooldown = 3600000 // 1 jam
    let timeDiff = Date.now() - last
    let remaining = cooldown - timeDiff

    if (timeDiff < cooldown) {
        return m.reply(
`⏳ Kamu baru aja berburu 😌

Tunggu *${clockString(remaining)}* lagi ya...
Biar tenaga kamu pulih dulu 💤`
        )
    }

    // 🎭 START
    m.reply(pickRandom([
        '🏹 Kamu masuk ke dalam hutan...',
        '🌲 Hutan terasa sunyi... kamu mulai berburu...',
        '🏹 Kamu menyiapkan senjata dan masuk ke hutan...'
    ]))

    setTimeout(() => {
        m.reply(pickRandom([
            '👀 Lagi nyari jejak hewan...',
            '🍃 Denger suara dari semak-semak...',
            '🕵️ Kamu mengendap-endap...'
        ]))
    }, 3000)

    setTimeout(() => {
        m.reply(pickRandom([
            '🎯 Target terlihat!',
            '🔥 Ada mangsa di depan!',
            '😈 Saatnya menyerang!'
        ]))
    }, 6000)

    setTimeout(() => {

        let hasil = {
            banteng: Math.floor(Math.random() * 10),
            harimau: Math.floor(Math.random() * 10),
            gajah: Math.floor(Math.random() * 10),
            kambing: Math.floor(Math.random() * 10),
            panda: Math.floor(Math.random() * 10),
            buaya: Math.floor(Math.random() * 10),
            kerbau: Math.floor(Math.random() * 10),
            sapi: Math.floor(Math.random() * 10),
            monyet: Math.floor(Math.random() * 10),
            babihutan: Math.floor(Math.random() * 10),
            babi: Math.floor(Math.random() * 10),
            ayam: Math.floor(Math.random() * 10)
        }

        // 🧠 INIT BIAR GAK ERROR
        for (let key in hasil) {
            if (!user[key]) user[key] = 0
            user[key] += hasil[key]
        }

        user.lastberburu = Date.now()

        let total = Object.values(hasil).reduce((a, b) => a + b, 0)

        // 😐 ZONK
        if (total === 0) {
            return conn.reply(m.chat, '😐 Yah... hutan lagi sepi, gak dapet apa-apa...', m)
        }

        // 📦 HASIL BOX
        conn.reply(m.chat,
`╭━━━〔 🏹 HASIL BERBURU 〕━━━⬣
┃ 🐂 Banteng   : ${hasil.banteng}
┃ 🐅 Harimau   : ${hasil.harimau}
┃ 🐘 Gajah     : ${hasil.gajah}
┃ 🐐 Kambing   : ${hasil.kambing}
┃ 🐼 Panda     : ${hasil.panda}
┃ 🐊 Buaya     : ${hasil.buaya}
┃
┃ 🐃 Kerbau    : ${hasil.kerbau}
┃ 🐄 Sapi      : ${hasil.sapi}
┃ 🐒 Monyet    : ${hasil.monyet}
┃ 🐗 Babi Hutan: ${hasil.babihutan}
┃ 🐖 Babi      : ${hasil.babi}
┃ 🐓 Ayam      : ${hasil.ayam}
╰━━━━━━━━━━━━━━━━⬣

✨ Total: ${total}
📦 Semua hasil masuk ke inventory 😏`,
        m)

    }, 10000)
}

handler.help = ['berburu']
handler.tags = ['rpg']
handler.command = /^(berburu|hunt)$/i
handler.rpg = true

module.exports = handler

// FUNCTION
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, '0'))
        .join(':')
}