let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    let id = m.sender

    let cooldown = 3600000 // 1 jam
    let now = Date.now()

    let timeLeft = cooldown - (now - (user.kerjaempat || 0))

    let kerja = 'Bunuh'
    conn.misi = conn.misi || {}

    if (id in conn.misi) {
        return conn.reply(m.chat, `⚠️ Selesaikan misi *${conn.misi[id].name}* terlebih dahulu!`, m)
    }

    if (now - (user.kerjaempat || 0) < cooldown) {
        return m.reply(`⏳ Tunggu dulu...\nBisa kembali dalam: *${clockString(timeLeft)}*`)
    }

    let uang = Math.floor(Math.random() * 1000000) + 200000
    let exp = Math.floor(Math.random() * 5000) + 1000

    let idUser = id.split('@')[0]

    // 🕵️ storyline
    let steps = [
        "🔍 Mencari target.....",
        "🕵️ Menemukan target.....",
        "⚔️ Menyerang target.....",
        "☠️ Target berhasil dieliminasi.....",
        "💼 Mengambil barang berharga....."
    ]

    let delay = [0, 8000, 15000, 22000, 30000]

    steps.forEach((text, i) => {
        setTimeout(() => {
            m.reply(text)
        }, delay[i])
    })

    let result = `
🎯 *HITMAN SUCCESS*
━━━━━━━━━━━━━━
👤 Player : @${idUser}

💰 Uang   : +${uang.toLocaleString()}
✨ EXP    : +${exp.toLocaleString()}
⚠️ Crime  : +1

✔ Misi selesai dengan sukses
━━━━━━━━━━━━━━
`.trim()

    setTimeout(() => {
        conn.reply(m.chat, result, m, {
            contextInfo: {
                mentionedJid: [m.sender]
            }
        })
    }, 32000)

    user.money += uang
    user.exp += exp
    user.warn += 1
    user.kerjaempat = now

    conn.misi[id] = {
        name: kerja,
        timeout: setTimeout(() => {
            delete conn.misi[id]
        }, cooldown)
    }
}

handler.help = ['hitman']
handler.tags = ['rpg']
handler.command = /^(bunuh|hitman)$/i

handler.register = true
handler.group = true
handler.level = 10
handler.rpg = true

module.exports = handler


function clockString(ms) {
    if (ms < 0) ms = 0
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, 0))
        .join(':')
}