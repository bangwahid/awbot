let handler = async (m, { conn, usedPrefix }) => {
    try {
        let user = global.db.data.users[m.sender]

        // ⚔️ CHECK EQUIP
        if (!user.sword) {
            return conn.reply(m.chat,
`╭──〔 ⚔️ GAGAL ADVENTURE 〕──⬣
│ Kamu belum punya sword
│ Craft: ${usedPrefix}craft sword
╰────────────────────⬣`, m)
        }

        if (!user.armor) {
            return conn.reply(m.chat,
`╭──〔 🛡️ GAGAL ADVENTURE 〕──⬣
│ Kamu belum punya armor
│ Craft: ${usedPrefix}craft armor
╰────────────────────⬣`, m)
        }

        // ⏳ COOLDOWN 3 MENIT
        let cooldown = 180000
        let time = user.lastadventure + cooldown
        let remaining = time - Date.now()

        if (Date.now() - user.lastadventure < cooldown) {
            return conn.reply(m.chat,
`╭──〔 ⏳ COOLDOWN 〕──⬣
│ Kamu masih lelah adventure
│ Tunggu: ${clockString(remaining < 0 ? 0 : remaining)}
╰────────────────────⬣`, m)
        }

        // 🌍 LOKASI
        let peta = pickRandom([
            '🇮🇩 Indonesia','🇯🇵 Jepang','🇰🇷 Korea','🇺🇸 Amerika',
            '🇬🇧 Inggris','🇫🇷 Prancis','🇩🇪 Jerman','🇮🇹 Italia',
            '🇪🇸 Spanyol','🇷🇺 Rusia','🇨🇳 China','🇮🇳 India',
            '🇧🇷 Brasil','🏝️ Pulau Misterius','🌋 Gunung Api',
            '🏜️ Gurun Sahara','❄️ Kutub Utara','🌊 Laut Dalam'
        ])

        // 👾 MUSUH
        let enemy = pickRandom([
            'Goblin',
            'Troll',
            'Zombie',
            'Orc',
            'Dragon',
            'Vampire',
            'Werewolf'
        ])

        // 💥 DAMAGE
        let damage = Math.floor(Math.random() * 80)

        // 💰 REWARD
        let exp = Math.floor(Math.random() * 10000)
        let money = Math.floor(Math.random() * 100000)

        // 🎁 ITEM DROP
        let potion = pickRandom([1,2,3])
        let sampah = Math.floor(Math.random() * 50)

        let diamond = Math.floor(Math.random() * 10)
        let berlian = Math.floor(Math.random() * 5)
        let emas = Math.floor(Math.random() * 20)
        let iron = Math.floor(Math.random() * 30)
        let batu = Math.floor(Math.random() * 40)
        let kayu = Math.floor(Math.random() * 50)
        let coal = Math.floor(Math.random() * 25)

        // 📦 DROP BOX SYSTEM
        let common = Math.floor(Math.random() * 5) + 1
        let uncommon = Math.floor(Math.random() * 5) + 1
        let mythic = Math.floor(Math.random() * 5) + 1
        let legendary = Math.floor(Math.random() * 5) + 1

        let box = [
            `📦 Common +${common}`,
            `🎁 Uncommon +${uncommon}`,
            `🔮 Mythic +${mythic}`,
            `👑 Legendary +${legendary}`
        ]

        // 🔥 CRITICAL
        let crit = Math.random() < 0.15
            ? '🔥 CRITICAL SUCCESS!'
            : ''

        // 📝 CAPTION
        let caption = `
╭──〔 ${crit} 🩸 ADVENTURE 〕──⬣
│ 🌍 Lokasi : ${peta}
│ ⚔️ Musuh  : ${enemy}
│ 💥 Damage : -${damage}
╰────────────────────⬣

╭──〔 💰 REWARD 〕──⬣
│ ✨ Exp   : ${exp}
│ 💰 Money : ${money}
│ 🎫 Tiket : 1
╰────────────────────⬣

╭──〔 🎁 ITEM DROP 〕──⬣
│ 🧪 Potion  : ${potion}
│ 💎 Diamond : ${diamond}
│ 💠 Berlian : ${berlian}
│ 🪙 Emas    : ${emas}
│ ⛓️ Iron    : ${iron}
│ 🪨 Batu    : ${batu}
│ 🪵 Kayu    : ${kayu}
│ ⚫ Coal    : ${coal}
│ 🗑️ Sampah  : ${sampah}
╰────────────────────⬣

╭──〔 📦 DROP BOX 〕──⬣
│ ${box.join('\n│ ')}
╰────────────────────⬣
`.trim()

        // 📤 SEND MESSAGE
        await conn.sendMessage(m.chat, {
            image: {
                url: 'https://telegra.ph/file/221ec27b2997f203569eb.jpg'
            },
            caption,
            mentions: [m.sender]
        }, { quoted: m })

        // 📊 UPDATE USER
        user.healt -= damage
        if (user.healt < 1) user.healt = 1

        user.exp += exp
        user.money += money

        user.potion += potion
        user.sampah += sampah

        user.diamond += diamond
        user.berlian += berlian
        user.emas += emas
        user.iron += iron
        user.batu += batu
        user.kayu += kayu
        user.coal += coal

        user.common += common
        user.uncommon += uncommon
        user.mythic += mythic
        user.legendary += legendary

        user.lastadventure = Date.now()

        // ⚔️ DURABILITY
        user.sworddurability -= 1
        user.armordurability -= 1

        // ⚔️ SWORD BROKEN
        if (user.sworddurability <= 0) {
            user.sword = false

            conn.reply(m.chat,
`╭──〔 ⚔️ RUSAK 〕──⬣
│ Sword kamu hancur
╰────────────────────⬣`, m)
        }

        // 🛡️ ARMOR BROKEN
        if (user.armordurability <= 0) {
            user.armor = false

            conn.reply(m.chat,
`╭──〔 🛡️ RUSAK 〕──⬣
│ Armor kamu hancur
╰────────────────────⬣`, m)
        }

    } catch (e) {
        console.log(e)

        conn.reply(m.chat,
`❌ Error Adventure

📌 ${e.message}

⚡ Powered by AW BOT`,
m)
    }
}

handler.help = ['adventure', 'adv']
handler.tags = ['rpg']
handler.command = /^(adventure|adv)$/i
handler.limit = true
handler.group = true
handler.rpg = true

module.exports = handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60

    return [h, m, s]
        .map(v => v.toString().padStart(2, '0'))
        .join(':')
}