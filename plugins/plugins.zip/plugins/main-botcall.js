let handler = async (m, { conn }) => {
    let tag = `@${m.sender.split('@')[0]}`

    let teks = [
`Hai ${tag} 
Aku di sini~`,

`Iya ${tag}? 
Mangil aku nih?`,

`Halo ${tag} 
Aku lagi online nih!`,

`Kenapa ${tag} 
Ada yang dicari ya?`,

`Hmm ${tag} 
Aku denger kok~`,

`${tag} manggil aku? 
Ada apa nih?`,

`Yo ${tag} 
Santai, aku standby`,

`Halo ${tag} 
Aku siap nemenin`,

// jawa
`Halo ${tag} 
Ana opo toh? `,

`${tag} manggil aku? 
Opo sing iso tak bantu?`,

`Yo ${tag} 
Aku neng kene kok`,

`${tag} iki ngopo 
Kok manggil aku?`,

`Halo ${tag} 
Aku siap bantu, santai ae`,

`${tag} piye kabare? 
Manggil aku ono perlu ta?`,

// tambahan spesial 😏
`Dalem sayang, ${tag}`
    ]

    conn.reply(
        m.chat,
        teks[Math.floor(Math.random() * teks.length)],
        m,
        { mentions: [m.sender] }
    )
}

handler.customPrefix = /^(bot|aw|awbot)$/i
handler.command = new RegExp

handler.help = ['bot']
handler.tags = ['main']

module.exports = handler