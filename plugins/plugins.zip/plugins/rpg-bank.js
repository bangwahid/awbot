let handler = async (m, { conn, usedPrefix }) => {
  let target = m.mentionedJid[0] || m.sender
  let user = global.db.data.users[target]

  let name = user.name || '-'
  let exp = user.exp || 0
  let limit = user.limit || 0
  let balance = user.money || 0
  let atm = user.bank || user.atm || 0
  let level = user.level || 0
  let role = user.role || '-'

  let capt = `🏦 B A N K - U S E R 🏦\n\n`
  capt += `👤 Nama   : ${name}\n`
  capt += `⭐ Role   : ${role}\n`
  capt += `✨ Exp    : ${exp}\n`
  capt += `📊 Limit  : ${limit}\n`
  capt += `💰 Saldo  : ${balance}\n`
  capt += `📈 Level  : ${level}\n`
  capt += `🏧 ATM    : ${atm}\n\n`
  capt += `> ${usedPrefix}atm <jumlah> untuk menabung\n`
  capt += `> ${usedPrefix}tarik<jumlah> untuk menarik uang\n`

  await conn.reply(m.chat, capt, m, {
    mentions: [target]
  })
}

handler.help = ['bank']
handler.tags = ['rpg']
handler.command = /^bank$/i
handler.rpg = true

module.exports = handler