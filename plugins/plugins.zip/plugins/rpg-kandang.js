let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let banteng = user.banteng || 0
    let harimau = user.harimau || 0
    let gajah = user.gajah || 0
    let kambing = user.kambing || 0
    let panda = user.panda || 0
    let buaya = user.buaya || 0
    let kerbau = user.kerbau || 0
    let sapi = user.sapi || 0
    let monyet = user.monyet || 0
    let babihutan = user.babihutan || 0
    let babi = user.babi || 0
    let ayam = user.ayam || 0

    let total =
        banteng + harimau + gajah + kambing + panda +
        buaya + kerbau + sapi + monyet + babihutan +
        babi + ayam

    let cap = `
╭━━━〔 🐾 KANDANG BURUAN 〕━━━⬣
👤 Player : @${m.sender.split`@`[0]}

🐂 Banteng   : ${banteng}
🐅 Harimau   : ${harimau}
🐘 Gajah     : ${gajah}
🐐 Kambing   : ${kambing}
🐼 Panda     : ${panda}

🐊 Buaya     : ${buaya}
🐃 Kerbau    : ${kerbau}
🐮 Sapi      : ${sapi}
🐒 Monyet    : ${monyet}

🐗 Babi hutan: ${babihutan}
🐖 Babi      : ${babi}
🐓 Ayam      : ${ayam}

📊 TOTAL HEWAN : ${total}

💡 Gunakan *${usedPrefix}pasar* untuk jual
💡 Gunakan *${usedPrefix}cook* untuk masak
╰━━━━━━━━━━━━━━━━⬣
`.trim()

    conn.reply(m.chat, cap, m, {
        mentions: await conn.parseMention(cap)
    })
}

handler.help = ['kandang']
handler.tags = ['rpg']
handler.command = /^(kandang)$/i
handler.rpg = true

module.exports = handler