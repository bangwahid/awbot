const timeout = 600000 // 10 menit (biar sama kayak mulung, bebas ubah)

let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    let time = user.lastnebang + timeout

    if (new Date - user.lastnebang < timeout) {
        return conn.reply(m.chat, `
╭───〔 🌳 COOLDOWN NEBANG 〕───⬣
│ Kamu sudah nebang sebelumnya
│ ⏱️ Tunggu : ${msToTime(time - new Date())}
╰────────────────────────⬣
`.trim(), m)
    }

    // hasil random
    let kayu = Math.floor(Math.random() * 45)

    user.kayu += kayu
    user.lastnebang = new Date * 1

    conn.reply(m.chat, `
╭───〔 🌲 HASIL NEBANG 〕───⬣
│ 🪵 Kayu : +${kayu}
╰────────────────────────⬣
`.trim(), m)
}

handler.help = ['nebang']
handler.tags = ['rpg']
handler.command = /^(nebang)$/i
handler.group = true
handler.rpg = true

handler.fail = null
handler.limit = true
handler.exp = 0
handler.money = 0

module.exports = handler

function msToTime(duration) {
    var seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    hours = (hours < 10) ? "0" + hours : hours
    minutes = (minutes < 10) ? "0" + minutes : minutes
    seconds = (seconds < 10) ? "0" + seconds : seconds

    return `${hours} jam ${minutes} menit ${seconds} detik`
}