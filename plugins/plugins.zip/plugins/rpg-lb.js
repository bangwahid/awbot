let handler = async (m, { conn, args, participants }) => { 
    let users = Object.entries(global.db.data.users).map(([key, value]) => {
        return { ...value, jid: key }
    })

    let sortedExp = users.map(toNumber('exp')).sort(sort('exp', false))
    let sortedLim = users.map(toNumber('limit')).sort(sort('limit', false))
    let sortedLevel = users.map(toNumber('level')).sort(sort('level', false))
    let sortedMoney = users.map(toNumber('money')).sort(sort('money', false))
    let sortedBank = users.map(toNumber('bank')).sort(sort('bank', false))

    let getName = (jid) => {
        return conn.getName(jid) || jid.split('@')[0]
    }

    let len = args[0] ? Math.min(10, Math.max(parseInt(args[0]), 10)) : 10

    let formatRank = (list, key, label, emoji) => {
        return `\n💠 *${emoji} ${label} TOP ${len}*\n` +
            `━━━━━━━━━━━━━━\n` +
            list.slice(0, len).map((u, i) => {
                let name = getName(u.jid)
                let value = (u[key] || 0).toLocaleString()

                let isHere = participants.some(p => p.jid === u.jid)

                return `${i + 1}. ${isHere ? '' : '@'}${u.jid.split('@')[0]} — *${value}*`
            }).join('\n')
    }

    let text = `
📊 *LEADERBOARD RPG SERVER*
━━━━━━━━━━━━━━━━━━

👤 Kamu Rank:
- XP: *${sortedExp.findIndex(x => x.jid === m.sender) + 1}*
- Limit: *${sortedLim.findIndex(x => x.jid === m.sender) + 1}*
- Level: *${sortedLevel.findIndex(x => x.jid === m.sender) + 1}*
- Money: *${sortedMoney.findIndex(x => x.jid === m.sender) + 1}*
- Bank: *${sortedBank.findIndex(x => x.jid === m.sender) + 1}*

${formatRank(sortedExp, 'exp', 'EXP', '⚡')}

${formatRank(sortedLim, 'limit', 'LIMIT', '🎟️')}

${formatRank(sortedLevel, 'level', 'LEVEL', '🏆')}

${formatRank(sortedMoney, 'money', 'MONEY', '💰')}

${formatRank(sortedBank, 'bank', 'BANK', '🏦')}

━━━━━━━━━━━━━━━━━━
`.trim()

    let allMention = [
        ...sortedExp.slice(0, len),
        ...sortedLim.slice(0, len),
        ...sortedLevel.slice(0, len),
        ...sortedMoney.slice(0, len),
        ...sortedBank.slice(0, len)
    ].map(v => v.jid)

    conn.reply(m.chat, text, m, {
        contextInfo: {
            mentionedJid: allMention
        }
    })
}

handler.help = ['leaderboard <jumlah>']
handler.tags = ['info']
handler.command = /^(leaderboard|lb)$/i

handler.group = true
handler.rpg = true

module.exports = handler


function sort(property, ascending = true) {
    if (property) return (a, b) => 
        ascending 
            ? a[property] - b[property] 
            : b[property] - a[property]
}

function toNumber(property, _default = 0) {
    return (obj) => ({
        ...obj,
        [property]: obj[property] || _default
    })
}