let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]

  let lastFishingTime = user.lastmancing || 0
  let cooldown = 180000 // 3 menit
  let timeDiff = Date.now() - lastFishingTime

  if (user.fishingrod < 1) {
    return conn.reply(m.chat,
`╭──〔 🎣 GAGAL MANCING 〕──⬣
│ ❌ Kamu tidak punya Fishing Rod
│ 🛠️ Craft dulu di menu
╰──────────────────⬣`, m)
  }

  if (timeDiff < cooldown) {
    return conn.reply(m.chat,
`╭──〔 ⏳ COOLDOWN 〕──⬣
│ 🎣 Kamu sudah memancing
│ ⏱️ Tunggu : ${formatTime(cooldown - timeDiff)}
╰──────────────────⬣`, m)
  }

  conn.reply(m.chat,
`╭──〔 🎣 MEMANCING 〕──⬣
│ 🌊 Kamu melempar pancing...
╰──────────────────⬣`, m)

  await delay(3000)
  conn.reply(m.chat, `🌊 Umpan di laut...`, m)

  await delay(3000)
  conn.reply(m.chat, `🐟 Ikan mulai mendekat...`, m)

  await delay(3000)
  conn.reply(m.chat, `🎯 Tarikan terasa kuat!`, m)

  await delay(3000)

  // ===== HASIL IKAN (FULL LIST) =====
  let hasil = {
    hiu: Math.floor(Math.random() * 3),
    ikan: Math.floor(Math.random() * 80),
    dory: Math.floor(Math.random() * 5),
    orca: Math.floor(Math.random() * 2),
    paus: Math.floor(Math.random() * 2),

    cumi: Math.floor(Math.random() * 20),
    gurita: Math.floor(Math.random() * 15),
    buntal: Math.floor(Math.random() * 10),
    udang: Math.floor(Math.random() * 100),
    lumba: Math.floor(Math.random() * 5),
    lobster: Math.floor(Math.random() * 8),
    kepiting: Math.floor(Math.random() * 60)
  }

  let totalCatch =
    hasil.hiu + hasil.ikan + hasil.dory + hasil.orca + hasil.paus +
    hasil.cumi + hasil.gurita + hasil.buntal + hasil.udang +
    hasil.lumba + hasil.lobster + hasil.kepiting

  // ===== UPDATE USER =====
  user.hiu = (user.hiu || 0) + hasil.hiu
  user.ikan = (user.ikan || 0) + hasil.ikan
  user.dory = (user.dory || 0) + hasil.dory
  user.orca = (user.orca || 0) + hasil.orca
  user.paus = (user.paus || 0) + hasil.paus

  user.cumi = (user.cumi || 0) + hasil.cumi
  user.gurita = (user.gurita || 0) + hasil.gurita
  user.buntal = (user.buntal || 0) + hasil.buntal
  user.udang = (user.udang || 0) + hasil.udang
  user.lumba = (user.lumba || 0) + hasil.lumba
  user.lobster = (user.lobster || 0) + hasil.lobster
  user.kepiting = (user.kepiting || 0) + hasil.kepiting

  user.fishingrod -= 1
  user.lastmancing = Date.now()

  let caption = `
╭━━━〔 🎣 IKAN HASIL TANGKAPAN 〕━━━⬣
👤 Player : @${m.sender.split('@')[0]}

🦈 Hiu       : ${hasil.hiu}
🐠 Ikan      : ${hasil.ikan}
🐬 Dory      : ${hasil.dory}
🐋 Orca      : ${hasil.orca}
🐳 Paus      : ${hasil.paus}

🦑 LAUT DALAM
🐙 Cumi      : ${hasil.cumi}
🪼 Gurita    : ${hasil.gurita}
🐡 Buntal    : ${hasil.buntal}
🦐 Udang     : ${hasil.udang}
🐬 Lumba²    : ${hasil.lumba}
🦞 Lobster   : ${hasil.lobster}
🦀 Kepiting  : ${hasil.kepiting}

📊 TOTAL IKAN : ${totalCatch}

💡 Gunakan *.mancing* untuk menangkap lagi
╰━━━━━━━━━━━━━━━━⬣
`

  conn.reply(m.chat, caption, m, {
    mentions: [m.sender]
  })
}

handler.help = ['mancing']
handler.tags = ['rpg']
handler.command = /^(mancing|memancing)$/i
handler.rpg = true

module.exports = handler

function delay(ms) {
  return new Promise(res => setTimeout(res, ms))
}

function formatTime(ms) {
  let s = Math.floor(ms / 1000) % 60
  let m = Math.floor(ms / 60000) % 60
  let h = Math.floor(ms / 3600000)

  return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`
}