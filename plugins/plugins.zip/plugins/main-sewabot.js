let handler = async (m, { conn, command }) => {
    let txt = `
╭━━━〔 🤖 SEWA BOT 〕━━━⬣

│ ⬡ 7 Hari   → Rp5.000
│ ⬡ 14 Hari → Rp10.000
│ ⬡ 30 Hari → Rp20.000

╰━━━〔 📩 ORDER 〕━━━⬣
Hubungi Owner:\n${global.owner.map(v => '@' + v[0]).join('\n')}

╰━━━〔 Terima Kasih 〕━━━⬣
`;

    try {
        await m.reply(txt)
    } catch (error) {
        console.error(error);
    }
};

handler.help = ['sewabot'];
handler.tags = ['main'];
handler.command = /^(sewa|sewabot)$/i;

module.exports = handler;
