const moneymins = 1

let handler = async (m, { conn, command, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let count = command.replace(/^pull|^tarik/i, '')
    count = count
        ? /all/i.test(count)
            ? Math.floor(user.bank / moneymins)
            : parseInt(count)
        : args[0]
            ? parseInt(args[0])
            : 1

    count = Math.max(1, count)

    if (isNaN(count)) {
        return conn.reply(m.chat,
`🏦 Masukkan jumlah ATM yang ingin ditarik.

Contoh:
${usedPrefix}pull 10
${usedPrefix}pullall
${usedPrefix}tarik 100`, m)
    }

    let total = moneymins * count

    if (user.bank < total) {
        return conn.reply(m.chat,
`❌ ATM kamu tidak cukup!

🏦 ATM kamu:
${user.bank}

💸 Dibutuhkan:
${total} ATM`, m)
    }

    user.bank -= total
    user.money += count

    conn.reply(m.chat,
`🏧 *BERHASIL MENARIK UANG*

🏦 -${total} ATM
💰 +${count} Money

📊 Saldo Sekarang:
💰 Money: ${user.money}
🏦 ATM: ${user.bank}`,
m)
}

handler.help = [
    'pull <jumlah>',
    'pullall',
    'tarik <jumlah>',
    'tarikall'
]

handler.tags = ['rpg']
handler.command = /^(pull([0-9]+)?|pullall|tarik([0-9]+)?|tarikall)$/i

handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.limit = true
handler.admin = false
handler.botAdmin = false
handler.rpg = true

handler.fail = null
handler.exp = 0

module.exports = handler