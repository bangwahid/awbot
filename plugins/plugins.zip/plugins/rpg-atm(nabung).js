const moneyplus = 1

let handler = async (m, { conn, command, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    let count = command.replace(/^atm/i, '')
    count = count
        ? /all/i.test(count)
            ? Math.floor(user.money / moneyplus)
            : parseInt(count)
        : args[0]
            ? parseInt(args[0])
            : 1

    count = Math.max(1, count)

    if (isNaN(count)) {
        return conn.reply(m.chat,
`🏦 Masukkan jumlah ATM yang ingin disimpan.

Contoh:
${usedPrefix}atm 10
${usedPrefix}atmall`, m)
    }

    let total = moneyplus * count

    if (user.money < total) {
        return conn.reply(m.chat,
`❌ Money kamu tidak cukup!

💰 Money kamu:
${user.money}

🏦 Dibutuhkan:
${total} Money`, m)
    }

    user.money -= total
    user.bank += count

    conn.reply(m.chat,
`🏦 *BERHASIL MENABUNG*

💸 -${total} Money
🏧 +${count} ATM

📊 Saldo Sekarang:
💰 Money: ${user.money}
🏦 ATM: ${user.bank}`,
m)
}

handler.help = ['atm <jumlah>', 'atmall']
handler.tags = ['rpg']
handler.command = /^(atm([0-9]+)|atm|atmall)$/i

handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.limit = true
handler.admin = false
handler.botAdmin = false
handler.rpg = true

handler.fail = null
handler.exp = 0

module.exports = handler