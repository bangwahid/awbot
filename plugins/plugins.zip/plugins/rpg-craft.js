let handler = async (m, { conn, args, command, usedPrefix }) => {
    let type = (args[0] || '').toLowerCase()
    let user = global.db.data.users[m.sender]

    const recipes = {
        pickaxe: {
            name: '⛏️ Pickaxe',
            materials: { kayu: 10, batu: 5, iron: 5, string: 20 },
            durability: 40,
            field: 'pickaxe',
            dura: 'pickaxedurability'
        },
        axe: {
            name: '🪓 Axe',
            materials: { kayu: 15, batu: 10, iron: 15, string: 10 },
            durability: 40,
            field: 'axe',
            dura: 'axedurability'
        },
        sword: {
            name: '⚔️ Sword',
            materials: { kayu: 10, iron: 15 },
            durability: 40,
            field: 'sword',
            dura: 'sworddurability'
        },
        pisau: {
            name: '🔪 Pisau',
            materials: { kayu: 15, iron: 20 },
            durability: 40,
            field: 'pisau',
            dura: 'pisaudurability'
        },
        bow: {
            name: '🏹 Bow',
            materials: { kayu: 10, iron: 5, string: 10 },
            durability: 40,
            field: 'bow',
            dura: 'bowdurability'
        },
        fishingrod: {
            name: '🎣 Fishing Rod',
            materials: { kayu: 10, iron: 2, string: 20 },
            durability: 40,
            field: 'fishingrod',
            dura: 'fishingroddurability'
        },
        armor: {
            name: '🥼 Armor',
            materials: { iron: 5, diamond: 1 },
            durability: 50,
            field: 'armor',
            dura: 'armordurability'
        },
        katana: {
            name: '🦯 Katana',
            materials: { kayu: 10, iron: 15, diamond: 5, emerald: 3 },
            durability: 40,
            field: 'katana',
            dura: 'katanadurability'
        }
    }

    let caption = `
╭━━━〔 ⚒️ BLACKSMITH 〕━━━⬣
┃
┃ 📌 *Cara Craft:*
┃ ${usedPrefix}craft sword
┃
┣━━━〔 📜 LIST ITEM 〕━━━⬣
┃ ⛏️ pickaxe
┃ ⚔️ sword
┃ 🎣 fishingrod
┃ 🥼 armor
┃ 🦯 katana
┃ 🪓 axe
┃ 🏹 bow
┃ 🔪 pisau
╰━━━━━━━━━━━━━━━━⬣

> © AW BOT RPG
`.trim()

    if (!type) {
        return conn.sendMessage(m.chat, {
            image: {
                url: 'https://telegra.ph/file/ed878d04e7842407c2b89.jpg'
            },
            caption
        }, { quoted: m })
    }

    let item = recipes[type]
    if (!item) return m.reply('❌ Item tidak ditemukan.')

    if (user[item.field] > 0) {
        return m.reply(`❌ Kamu sudah memiliki ${item.name}`)
    }

    let kurang = []

    for (let bahan in item.materials) {
        if (user[bahan] < item.materials[bahan]) {
            kurang.push(
                `• ${bahan}: ${item.materials[bahan] - user[bahan]}`
            )
        }
    }

    if (kurang.length > 0) {
        return m.reply(`
❌ Material tidak cukup untuk membuat ${item.name}

📦 Kekurangan:
${kurang.join('\n')}
        `.trim())
    }

    conn.reply(m.chat, `⚒️ Sedang membuat ${item.name}...`, m)

    await delay(3000)

    for (let bahan in item.materials) {
        user[bahan] -= item.materials[bahan]
    }

    user[item.field] += 1
    user[item.dura] = item.durability

    let txt = `
╭━━━〔 ✅ CRAFT BERHASIL 〕━━━⬣
┃
┃ 🎉 Berhasil membuat:
┃ ${item.name}
┃
┣━━━〔 📦 MATERIAL TERPAKAI 〕━━━⬣
${Object.entries(item.materials)
.map(([a, b]) => `┃ ${capitalize(a)} -${b}`)
.join('\n')}
┃
┣━━━〔 🛡️ INFO ITEM 〕━━━⬣
┃ Durability: ${item.durability}
┃
╰━━━━━━━━━━━━━━━━⬣

> © AW BOT RPG
`.trim()

    conn.reply(m.chat, txt, m)
}

handler.help = ['craft', 'blacksmith']
handler.tags = ['rpg']
handler.command = /^(craft|crafting|blacksmith)$/i
handler.register = true
handler.group = true
handler.rpg = true

module.exports = handler

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1)
}