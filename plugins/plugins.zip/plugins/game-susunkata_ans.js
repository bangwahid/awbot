const similarity = require('similarity')
const threshold = 0.72

let handler = m => m

handler.before = async function (m) {
    let id = m.chat
    if (!m.quoted) return !0

    this.susun = this.susun ? this.susun : {}
    if (!(id in this.susun)) return !0
    if (m.quoted.id !== this.susun[id][0].key.id) return !0

    let json = this.susun[id][1]
    let jawaban = json.jawaban.toLowerCase().trim()
    let teksUser = (m.text || '').toLowerCase().trim()

    if (!teksUser) return !0

    // ===============================
    // ✅ JAWABAN BENAR
    // ===============================
    if (teksUser === jawaban) {

        global.db.data.users[m.sender].money += this.susun[id][2]

        m.reply(`
🎉 *JAWABAN BENAR*

┌──────────────
💰 Anda mendapatkan uang sebesar ${this.susun[id][2]}
🎯 Jawaban : ${jawaban}
└──────────────
`.trim())

        clearTimeout(this.susun[id][3])
        delete this.susun[id]
    }

    // ===============================
    // ⚠️ HAMPIR BENAR
    // ===============================
    else if (similarity(teksUser, jawaban) >= threshold) {

        m.reply(`
⚠️ *DIKIT LAGI!*

┌──────────────
📌 Jawaban kamu hampir benar
🔎 Coba teliti lagi
└──────────────
`.trim())
    }

    // ===============================
    // ❌ SALAH
    // ===============================
    else {

        m.reply(`
❌ *JAWABAN SALAH*

┌──────────────
💡 Masih belum tepat
🔁 Silakan coba lagi
└──────────────
`.trim())
    }

    return !0
}

handler.exp = 0
module.exports = handler