let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    const timeout = 300000 // 5 menit

    let time = user.lastnambang + timeout

    if (new Date - user.lastnambang < timeout) {
        return conn.reply(m.chat, `
╭───〔 ⛏️ COOLDOWN NAMBANG 〕───⬣
│ 😴 Kamu kelelahan habis nambang
│ ⏱️ Tunggu : ${clockString(time - new Date())}
╰────────────────────────⬣
`.trim(), m)
    }

    user.lastnambang = new Date * 1

    // hasil basic mining
    let coal = Math.floor(Math.random() * 10)
    let iron = Math.floor(Math.random() * 10)
    let diamond = Math.floor(Math.random() * 5)
    let emas = Math.floor(Math.random() * 3)

    // tambahan hasil rare
    let berlian = Math.floor(Math.random() * 2)
    let ruby = Math.floor(Math.random() * 2)
    let emerald = Math.floor(Math.random() * 2)
    let tiket = 1

    let { key } = await conn.sendMessage(m.chat, { text: '⛏️ Mencari lokasi tambang terbaik...' })

    await delay(2000)
    await conn.sendMessage(m.chat, { text: '🪨 Mulai menggali tanah keras...', edit: key })

    await delay(2000)
    await conn.sendMessage(m.chat, { text: '💥 Batu pecah... menemukan mineral!', edit: key })

    await delay(2000)

    // masukin ke database
    user.coal += coal
    user.iron += iron
    user.diamond += diamond
    user.emas += emas
    user.berlian += berlian
    user.ruby += ruby
    user.emerald += emerald
    user.tiketcoin += tiket

    conn.sendMessage(m.chat, {
        text: `
╭━━━〔 ⛏️ HASIL NAMBANG 〕━━━⬣
┃ 🪨 Coal      : +${coal}
┃ ⛓️ Iron      : +${iron}
┃ 💎 Diamond   : +${diamond}
┃ ✨ Emas      : +${emas}
┃ 💠 Berlian   : +${berlian}
┃ ❤️ Ruby      : +${ruby}
┃ 💚 Emerald   : +${emerald}
┃ 🎟️ Tiket     : +${tiket}
╰━━━━━━━━━━━━━━━━⬣

💡 Semakin dalam kamu nambang, semakin rare hasilnya!
`.trim(),
        edit: key
    })
}

handler.help = ['nambang']
handler.tags = ['rpg']
handler.command = /^(nambang|mine|tambang)$/i
handler.register = true
handler.rpg = true

module.exports = handler

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}