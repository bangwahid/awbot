let handler = async (m, { conn, command, args, usedPrefix }) => {
    let type = (args[0] || '').toLowerCase()
    let user = global.db.data.users[m.sender]
    const timeout = 300000 // 5 menit

    let time = user.lastkerja + timeout

    let penumpang = pickRandom(['mas mas', 'bapak bapak', 'cewe sma', 'bocil epep', 'emak emak'])
    let dagangan = pickRandom(['wortel', 'sawi', 'selada', 'tomat', 'seledri', 'cabai', 'daging', 'ikan', 'ayam'])
    let pasien = pickRandom(['sakit kepala', 'cedera', 'luka bakar', 'patah tulang'])
    let panen = pickRandom(['Wortel', 'Kubis', 'strawberry', 'teh', 'padi', 'jeruk', 'pisang', 'semangka', 'durian', 'rambutan'])
    let bengkel = pickRandom(['mobil', 'motor', 'becak', 'bajai', 'bus', 'angkot', 'sepeda'])
    let rumah = pickRandom(['Membangun Rumah', 'Membangun Gedung', 'Memperbaiki Rumah', 'Memperbaiki Gedung', 'Membangun Fasilitas Umum', 'Memperbaiki Fasilitas Umum'])
    let penjahat = pickRandom(['pencuri', 'pelanggar lalu lintas', 'perampok bank', 'copet', 'koruptor'])

    if (/^kerja$/i.test(command)) {
        if (new Date - user.lastkerja < timeout) {
            return conn.reply(m.chat, `
╭───〔 ⏳ COOLDOWN KERJA 〕───⬣
│ Kamu sudah bekerja
│ ⏱️ Tunggu : ${clockString(time - new Date())}
╰────────────────────────⬣
`.trim(), m)
        }

        let hasil = Math.floor(Math.random() * 5000000)
        let teks = ''

        switch (type) {
            case 'ojek':
                teks = `Mengantarkan ${penumpang} 🚗`
                break
            case 'pedagang':
                teks = `Menjual ${dagangan} 🛒`
                break
            case 'dokter':
                teks = `Mengobati pasien ${pasien} 💉`
                break
            case 'petani':
                teks = `Panen ${panen} 🌽`
                break
            case 'montir':
                teks = `Memperbaiki ${bengkel} 🔧`
                break
            case 'kuli':
                teks = `${rumah} 🔨`
                break
            case 'polisi':
                teks = `Menangkap ${penjahat} 🚨`
                break
            default:
                return conn.reply(m.chat, `
╭───〔 📌 PILIH PEKERJAAN 〕───⬣
│ • kuli
│ • montir
│ • petani
│ • dokter
│ • pedagang
│ • ojek
│ • polisi
│
│ Contoh:
│ ${usedPrefix}kerja kuli
╰────────────────────────⬣
`.trim(), m)
        }

        user.money += hasil
        user.lastkerja = new Date * 1

        conn.reply(m.chat, `
╭───〔 💼 HASIL KERJA 〕───⬣
│ 🛠️ Aktivitas : ${teks}
│ 💰 Hasil     : Rp ${hasil} money
╰────────────────────────⬣
`.trim(), m)
    }
}

handler.help = ['kerja']
handler.tags = ['rpg']
handler.command = /^kerja$/i

handler.register = true
handler.group = true
handler.rpg = true

module.exports = handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}