let handler = async (m, { conn, text }) => {

    let q = m.quoted || m
    let mime = (q.msg || q).mimetype || ""

    try {

        // ambil semua kontak/group participant
        let groups = Object.values(
            await conn.groupFetchAllParticipating()
        )

        let users = []

        for (let group of groups) {
            for (let p of group.participants) {
                users.push(p.id)
            }
        }

        users = [...new Set(users)]

        //========================
        // TEXT
        //========================
        if (!mime) {

            await conn.sendMessage(
                "status@broadcast",
                {
                    text: text || ""
                },
                {
                    statusJidList: users
                }
            )
        }

        //========================
        // IMAGE
        //========================
        else if (/image/.test(mime)) {

            let media = await q.download()

            await conn.sendMessage(
                "status@broadcast",
                {
                    image: media,
                    caption: text || ""
                },
                {
                    statusJidList: users
                }
            )
        }

        //========================
        // VIDEO
        //========================
        else if (/video/.test(mime)) {

            let media = await q.download()

            await conn.sendMessage(
                "status@broadcast",
                {
                    video: media,
                    caption: text || ""
                },
                {
                    statusJidList: users
                }
            )
        }

        //========================
        // AUDIO
        //========================
        else if (/audio/.test(mime)) {

            let media = await q.download()

            await conn.sendMessage(
                "status@broadcast",
                {
                    audio: media,
                    mimetype: "audio/mp4",
                    ptt: false
                },
                {
                    statusJidList: users
                }
            )
        }

        m.reply("✅ Status berhasil dibuat")

    } catch (e) {

        console.log(e)

        m.reply(
`❌ Gagal upload status

${e.message}`
        )
    }
}

handler.help = ["upswbot <caption>"]
handler.tags = ["owner"]
handler.command = ["upswbot"]

handler.owner = true

module.exports = handler