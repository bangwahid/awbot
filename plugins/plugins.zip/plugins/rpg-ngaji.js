let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    const timeout = 300000 // 5 menit

    let time = user.lastngaji + timeout

    if (new Date - user.lastngaji < timeout) {
        return conn.reply(m.chat, `
╭───〔 ⏳ COOLDOWN NGAJI 〕───⬣
│ Kamu sudah ngaji sebelumnya
│ ⏱️ Tunggu : ${clockString(time - new Date())}
╰────────────────────────⬣
`.trim(), m)
    }

    // hasil random
    let uang = Math.floor(Math.random() * 5) * 15000
    let exp = Math.floor(Math.random() * 10) * 20000

    // animasi (edit message biar gak spam)
    let { key } = await conn.sendMessage(m.chat, { text: '📖 Mencari guru ngaji...' })

    await delay(2000)
    await conn.sendMessage(m.chat, { text: '🧕 Bertemu ustadz...', edit: key })

    await delay(2000)
    await conn.sendMessage(m.chat, { text: '📚 Mulai mengaji...', edit: key })

    await delay(2000)
    await conn.sendMessage(m.chat, { text: '✨ Belajar tajwid...', edit: key })

    await delay(2000)

    // hasil
    user.money += uang
    user.exp += exp
    user.warn = (user.warn || 0) - 1
    user.lastngaji = new Date * 1

    conn.sendMessage(m.chat, {
        text: `
╭───〔 📖 HASIL NGAJI 〕───⬣
│ 💰 Uang   : +${uang}
│ ✨ Exp    : +${exp}
│ 😅 Dimarahin : -1
╰────────────────────────⬣
`.trim(),
        edit: key
    })
}

handler.help = ['mengaji', 'ngaji']
handler.tags = ['rpg']
handler.command = /^(mengajikeliling|mengaji|ngaji|ustad|ustadz|ustaz)$/i
handler.register = true
handler.rpg = true

module.exports = handler

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}