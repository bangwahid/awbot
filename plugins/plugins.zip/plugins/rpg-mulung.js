const timeout = 300000 // 5 menit

let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]

    let time = user.lastturu + timeout

    if (new Date - user.lastturu < timeout) {
        return conn.reply(m.chat, `
╭───〔 ⏳ COOLDOWN MULUNG 〕───⬣
│ 😴 Kamu sudah mulung sebelumnya
│ ⏱️ Tunggu : ${msToTime(time - new Date())}
╰────────────────────⬣
`.trim(), m)
    }

    // 🎲 hasil mulung (random jumlah saja)
    let botolnye = rand(100, 1000)
    let kalengnye = rand(100, 1000)
    let kardusnye = rand(100, 1000)

    let plastik = rand(50, 500)
    let iron = rand(20, 200)
    let sampah = rand(50, 300)

    // 📦 BOX (SEMUANYA DAPAT, TIDAK RANDOM)
    let commonBox = rand(1, 3)
    let uncommonBox = rand(1, 2)
    let mythicBox = rand(1, 2)
    let legendaryBox = rand(0, 1)

    // masuk database
    user.botol += botolnye
    user.kaleng += kalengnye
    user.kardus += kardusnye

    user.plastik = (user.plastik || 0) + plastik
    user.iron = (user.iron || 0) + iron
    user.sampah = (user.sampah || 0) + sampah

    // BOX masuk
    user.common += commonBox
    user.uncommon += uncommonBox
    user.mythic += mythicBox
    user.legendary += legendaryBox

    user.lastturu = new Date * 1

    conn.reply(m.chat, `
╭━━━〔 🧺 HASIL MULUNG 〕━━━⬣
┃ 🧴 Botol        : +${botolnye}
┃ 🥫 Kaleng       : +${kalengnye}
┃ 📦 Kardus       : +${kardusnye}
┃ ♻️ Plastik      : +${plastik}
┃ ⛓️ Iron         : +${iron}
┃ 🗑️ Sampah       : +${sampah}
┃
┃ 📦 COMMON BOX    : +${commonBox}
┃ 📦 UNCOMMON BOX  : +${uncommonBox}
┃ 📦 MYTHIC BOX    : +${mythicBox}
┃ 👑 LEGENDARY BOX : +${legendaryBox}
╰━━━━━━━━━━━━━━━━⬣

💡 Semua jenis box berhasil didapat!
`.trim(), m)
}

handler.help = ['mulung']
handler.tags = ['rpg']
handler.command = /^(mulung)$/i
handler.group = true
handler.limit = true
handler.rpg = true

module.exports = handler

function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
}

function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60)
    let minutes = Math.floor((duration / (1000 * 60)) % 60)
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    return `${hours.toString().padStart(2,'0')} jam ${minutes.toString().padStart(2,'0')} menit ${seconds.toString().padStart(2,'0')} detik`
}