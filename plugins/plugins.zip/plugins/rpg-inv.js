let handler = async (m, { conn, args }) => {
  let target = m.mentionedJid[0] || m.sender
  let user = global.db.data.users[target]

  let armor = user.armor
  let sword = user.sword
  let fishingrod = user.fishingrod
  let pickaxe = user.pickaxe
  let katana = user.katana
  let bow = user.bow
  let axe = user.axe

  const armors = [
    'Tidak Punya','Leather Armor','Iron Armor','Gold Armor','Diamond Armor',
    'Emerald Armor','Crystal Armor','Obsidian Armor','Netherite Armor',
    'Wither Armor','Dragon Armor','Hacker Armor','GOD Armor'
  ]

  const swords = [
    'Tidak Punya','Wooden Sword','Iron Sword','Gold Sword','Diamond Sword',
    'Netherite Sword','Crystal Sword','Obsidian Sword','Netherite Sword',
    'Wither Sword','Dragon Sword','Hacker Sword','GOD Sword'
  ]

  const rods = [
    'Tidak Punya','Wood FishingRod','Iron FishingRod','Gold FishingRod',
    'Diamond FishingRod','Netherite FishingRod','Crystal FishingRod',
    'Obsidian FishingRod','Netherite FishingRod','Wither FishingRod',
    'Dragon FishingRod','Hacker FishingRod','GOD FishingRod'
  ]

  const pickaxes = [
    'Tidak Punya','Wood Pickaxe','Iron Pickaxe','Gold Pickaxe',
    'Diamond Pickaxe','Netherite Pickaxe','Crystal Pickaxe',
    'Obsidian Pickaxe','Netherite Pickaxe','Wither Pickaxe',
    'Dragon Pickaxe','Hacker Pickaxe','GOD Pickaxe'
  ]

  const katanas = [
    'Tidak Punya','Wood Katana','Iron Katana','Gold Katana',
    'Diamond Katana','Netherite Katana','Crystal Katana',
    'Obsidian Katana','Netherite Katana','Wither Katana',
    'Dragon Katana','Hacker Katana','GOD Katana'
  ]

  const axes = [
    'Tidak Punya','Wood Axe','Iron Axe','Gold Axe',
    'Diamond Axe','Netherite Axe','Crystal Axe',
    'Obsidian Axe','Netherite Axe','Wither Axe',
    'Dragon Axe','Hacker Axe','GOD Axe'
  ]

  const bows = [
    'Tidak Punya','Wood Bow','Iron Bow','Gold Bow',
    'Diamond Bow','Netherite Bow','Crystal Bow',
    'Obsidian Bow','Netherite Bow','Wither Bow',
    'Dragon Bow','Hacker Bow','GOD Bow'
  ]

  let capt = `
╔════『 INVENTORY USER 』
║ 👤 Name : ${user.name}
║ 🎖️ Role : ${user.role}
║ 📊 Level : ${user.level}
║ ✨ Exp : ${user.exp}
║ 💰 Money : ${user.money}
║ 🎫 Limit : ${user.limit}
║ 🏷️ Title : ${user.titlein}
║ ⚔️ Skill : ${user.skill || 'Tidak Ada'}
╚═════════════

╔════『 STATUS 』
║ ❤️ Health : ${user.healt}
║ ⚡ Energi : ${user.energi}
║ 🔋 Stamina : ${user.stamina}
║ 💨 Speed : ${user.speed}
║ 💪 Strength : ${user.strenght}
║ 🗡️ Attack : ${user.attack}
║ 🛡️ Defense : ${user.defense}
╚═════════════

╔════『 BACKPACK 』
║ 🧪 Potion : ${user.potion}
║ 💎 Diamond : ${user.diamond}
║ 🔷 Berlian : ${user.berlian}
║ 🟨 Emas : ${user.emas}
║ ⛓️ Iron : ${user.iron}
║ 🪨 Batu : ${user.batu}
║ 🪵 Kayu : ${user.kayu}
║ ⚫ Coal : ${user.coal}
║ 🗑️ Sampah : ${user.sampah}
╚═════════════

╔════『 BUAH BUAHAN 』
║ 🍌 Pisang : ${user.pisang}
║ 🍇 Anggur : ${user.anggur}
║ 🥭 Mangga : ${user.mangga}
║ 🍊 Jeruk : ${user.jeruk}
║ 🍎 Apel : ${user.apel}
╚═════════════

╔════『 BIBIT BUAH 』
║ 🌱 Bibit Pisang : ${user.bibitpisang}
║ 🌱 Bibit Anggur : ${user.bibitanggur}
║ 🌱 Bibit Mangga : ${user.bibitmangga}
║ 🌱 Bibit Jeruk : ${user.bibitjeruk}
║ 🌱 Bibit Apel : ${user.bibitapel}
║ 📦 Garden Box : ${user.gardenboxs}
╚═════════════

╔════『 SENJATA 』
║ 🛡️ Armor : ${armors[armor]}
║ ⚔️ Sword : ${swords[sword]}
║ 🎣 FishingRod : ${rods[fishingrod]}
║ ⛏️ Pickaxe : ${pickaxes[pickaxe]}
║ 🗡️ Katana : ${katanas[katana]}
║ 🪓 Axe : ${axes[axe]}
║ 🏹 Bow : ${bows[bow]}
╚═════════════

╔════『 DURABILITY 』
║ 🛡️ Armor : ${user.armordurability}
║ ⚔️ Sword : ${user.sworddurability}
║ 🎣 FishingRod : ${user.fishingroddurability}
║ ⛏️ Pickaxe : ${user.pickaxedurability}
║ 🗡️ Katana : ${user.katanadurability}
║ 🪓 Axe : ${user.axedurability}
║ 🏹 Bow : ${user.bowdurability}
╚═════════════

╔════『 USER BOX 』
║ 📦 Common : ${user.common}
║ 🎁 Uncommon : ${user.uncommon}
║ 🔮 Mythic : ${user.mythic}
║ 👑 Legendary : ${user.legendary}
║ 📊 Total : ${user.common + user.uncommon + user.mythic + user.legendary}
╚═════════════

╔════『 USER PETS 』
║ 🐾 Pet Token : ${user.pet}
║ 🍖 Makanan Pet : ${user.makananpet}
║ 🐱 Kucing : Lv.${user.kucing}
║ 🐶 Anjing : Lv.${user.anjing}
║ 🦊 Rubah : Lv.${user.rubah}
║ 🐺 Serigala : Lv.${user.serigala}
║ 🔥 Phonix : Lv.${user.phonix}
╚═════════════
`

  conn.fakeReply(
    m.chat,
    capt,
    '0@s.whatsapp.net',
    'Inventory RPG',
    'status@broadcast'
  )
}

handler.help = ['inventory *@user*']
handler.tags = ['rpg']
handler.command = /^(inv|inventory)$/i
handler.rpg = true

module.exports = handler